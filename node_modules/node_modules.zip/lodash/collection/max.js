module.exports = require('../math/max');
